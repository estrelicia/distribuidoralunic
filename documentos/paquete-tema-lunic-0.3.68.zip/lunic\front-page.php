<?php
get_header();
$slides = [
    'WhatsApp-Image-2026-08-20-at-3.36.24-PM.jpeg',
    'WhatsApp-Image-2026-08-20-at-3.36.24-PM-1.jpeg',
    'WhatsApp-Image-2026-07-29-at-4.14.01-PM.jpeg',
    'Capullos-de-te.jpeg',
    'Naranja-y-mix-de-citricos-en-rodajas.jpeg',
    'Retiros-de-mercaderia.jpeg',
    'Retiro-de-mercaderia.jpeg',
    'Acarreo-Via-cargo.png',
];
echo '<section class="lunic-slider" aria-label="Destacados"><div class="lunic-slider__track">';
foreach ($slides as $index => $file) {
    if ($index === 0) {
        $src = get_template_directory_uri() . '/assets/hero-1.webp';
        $path = get_template_directory() . '/assets/hero-1.webp';
    } else {
        $src = content_url('uploads/' . $file);
        $path = WP_CONTENT_DIR . '/uploads/' . $file;
    }
    $size = is_file($path) ? getimagesize($path) : false;
    $wh = (is_array($size) && $size[0] && $size[1]) ? ' width="' . (int) $size[0] . '" height="' . (int) $size[1] . '"' : '';
    $priority = $index === 0
        ? ' fetchpriority="high" decoding="async"'
        : ' loading="lazy" decoding="async"';
    echo '<img src="' . esc_url($src) . '" alt=""' . $wh . $priority . '>';
}
echo '</div></section>';
$catalog = function_exists('lunic_site') ? lunic_site('price_list_url') : '';
if ($catalog !== '') {
    echo '<p class="lunic-home-cta"><a href="' . esc_url($catalog) . '">Descargá la Lista de Precios</a></p>';
}
lunic_envios_accordion();
echo '<section class="lunic-home-intro"><h2>Productos de calidad</h2><h3>Siempre al mejor precio</h3>';
the_widget('WC_Widget_Products', [
    'title' => 'En oferta',
    'number' => 5,
    'show' => 'onsale',
    'orderby' => 'date',
    'order' => 'desc',
    'hide_free' => 1,
]);
echo '</section>';
echo '<section class="lunic-searchband"><h2>Buscador de productos</h2>';
if (shortcode_exists('lunic_search')) {
    echo do_shortcode('[lunic_search]');
}
echo '</section>';
get_footer();
